#include <Wire.h>
#include <PCF8575.h>
#include "ADS1X15.h"
#include <Joystick.h>
#include <Keyboard.h>
Joystick_ Joystick(JOYSTICK_DEFAULT_REPORT_ID,0x04,
  32, 0,                  // Button Count, Hat Switch Count
  true, true, false,     // X and Y, but no Z Axis
  false, false, false,   // No Rx, Ry, or Rz
  false, false,          // No rudder or throttle
  false, false, false);  // No accelerator, brake, or steering
PCF8575 PCF_20(0x20);
PCF8575 PCF_21(0x21);
ADS1115 ADS(0x48);

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  
  Wire.begin();
  Wire.setClock(400000);
  PCF_20.begin();
  PCF_21.begin();

  ADS.begin();
  ADS.setDataRate(7);
  ADS.setMode(1);
  ADS.setGain(0);
  
  Keyboard.begin();

  Joystick.begin();
  Joystick.setXAxisRange(0, 23800);
  Joystick.setYAxisRange(0, 22000);
}
uint16_t val1 = 0;
uint16_t val2 = 0;
int16_t adc0, adc1;
bool digital_V1=0;
uint8_t clock = 0;
int analogA0,analogA1;
void loop() {
  //long lasttime = millis();


  // put your main code here, to run repeatedly:
  val1 = PCF_20.read16();
  val2 = PCF_21.read16();
  
  adc0 = ADS.readADC(0); 
  Joystick.setXAxis(adc0);
  adc1 = ADS.readADC(1); 
  Joystick.setYAxis(adc1);


  if(bitRead(val1, 13)==0){
    Keyboard.press(KEY_LEFT_SHIFT); 
  }
  else{
    Keyboard.release(KEY_LEFT_SHIFT);
  }

  clock++;
  if(clock==1){
    for(int i=0;i<8;i++){
      bool num = !(bitRead(val1, i));
      Joystick.setButton(i,num);
      }
  }
  if(clock==2){
    for(int i=0;i<8;i++){
      bool num = !(bitRead(val1, i+8));
      Joystick.setButton(i+8,num);
      }
  }
  if(clock==3){
    for(int i=0;i<8;i++){
      bool num = !(bitRead(val2, i));
      Joystick.setButton(i+16,num);
      }
  }
  if(clock==4){
    clock=0;
    analogA0 = analogRead(A0);
    analogA1 = analogRead(A1);
    if(analogA0<=200){Joystick.setButton(24,1);}else{Joystick.setButton(24,0);}
    if(analogA1<=200){Joystick.setButton(25,1);}else{Joystick.setButton(25,0);}
    if(analogA0>=800){Joystick.setButton(26,1);}else{Joystick.setButton(26,0);}
    if(analogA1>=800){Joystick.setButton(27,1);}else{Joystick.setButton(27,0);}
    if(analogA0<=200&&analogA1<=200){Joystick.setButton(28,1);}else{Joystick.setButton(28,0);}
    if(analogA0>=800&&analogA1>=800){Joystick.setButton(29,1);}else{Joystick.setButton(29,0);}
    if(analogA0>=800&&analogA1<=200){Joystick.setButton(30,1);}else{Joystick.setButton(30,0);}
    if(analogA0<=200&&analogA1>=800){Joystick.setButton(31,1);}else{Joystick.setButton(31,0);}
  }
  
  
  
  

/*
  Serial.print(val1,BIN);Serial.print(" ");
  Serial.print(val2,BIN);Serial.print(" ");
  Serial.print(" "); Serial.print(adc0);
  Serial.print(" "); Serial.print(adc1);
  Serial.print(" "); Serial.print(analogA0);
  Serial.print(" "); Serial.print(analogA1);
  Serial.print(" ");Serial.println(millis()-lasttime);
  */

}
