

#include <Joystick.h>


Joystick_ Joystick(0x02,0x05,
  46, 0,                  // Button Count, Hat Switch Count
  true, false, false,     // X and Y, but no Z Axis
  false, false, false,   // No Rx, Ry, or Rz
  false, false,          // No rudder or throttle
  false, false, false);  // No accelerator, brake, or steering

const int A2_Sample_num = 5;          // 滑动窗口大小
const int stabilityThreshold = 3;     // 稳定阈值（差值<5不更新）
int A2_samples[A2_Sample_num] = {0};  // 初始化全0的缓冲区
int A2_writeIndex = 0;                // 写指针
int A2_sum = 0;                       // 当前窗口总和
int A2_last_stable_value = 0;         // 上次稳定值


void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  
  pinMode(0, INPUT_PULLUP);
  pinMode(1, INPUT_PULLUP);
  pinMode(2, INPUT_PULLUP);
  pinMode(3, INPUT_PULLUP);
  pinMode(4, INPUT_PULLUP);
  pinMode(5, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  pinMode(7, INPUT_PULLUP);
  pinMode(8, INPUT_PULLUP);
  pinMode(9, INPUT_PULLUP);
  pinMode(10, INPUT_PULLUP);
  pinMode(14, INPUT_PULLUP);
  pinMode(15, INPUT_PULLUP);
  pinMode(16, INPUT_PULLUP);

  Joystick.begin();
  Joystick.setXAxisRange(0, 1024);

}


uint8_t clock = 0;

int analogA0,analogA1,analogA2,analogA3;
bool buttonState[16];


void loop() {
  long lasttime = millis();
  clock++;

  // put your main code here, to run repeatedly:
  /*
  if(clock==1){
    for(int i=0;i<8;i++){
    bool num = !(bitRead(val1, i));
    Joystick.setButton(i,num);
    }
    
  }
  if(clock==2){
    for(int i=0;i<8;i++){
    bool num = !(bitRead(val1, i+8));
    Joystick.setButton(i+8,num);
    }
    
  }
  if(clock==3){
    for(int i=0;i<8;i++){
    bool num = !(bitRead(val2, i));
    Joystick.setButton(i+16,num);
    }
    
  }
  if(clock==4){
    clock=0;
    for(int i=0;i<8;i++){
    bool num = !(bitRead(val2, i+8));
    Joystick.setButton(i+24,num);
    }
  }
  */
  buttonState[0] = digitalRead(0);
  buttonState[1] = digitalRead(1);
  buttonState[2] = digitalRead(2);
  buttonState[3] = digitalRead(3);
  buttonState[4] = digitalRead(4);
  buttonState[5] = digitalRead(5);
  buttonState[6] = digitalRead(6);
  buttonState[7] = digitalRead(7);
  buttonState[8] = digitalRead(8);
  buttonState[9] = digitalRead(9);
  buttonState[10] = digitalRead(10);
  buttonState[14] = digitalRead(14);
  buttonState[15] = digitalRead(15);
  buttonState[16] = digitalRead(16);

  if(buttonState[0]==0){Joystick.setButton(0,1);Joystick.setButton(1,0);}else{Joystick.setButton(1,1);Joystick.setButton(0,0);}
  if(buttonState[1]==0){Joystick.setButton(2,1);Joystick.setButton(3,0);}else{Joystick.setButton(3,1);Joystick.setButton(2,0);}
  if(buttonState[2]==0){Joystick.setButton(4,1);Joystick.setButton(5,0);}else{Joystick.setButton(5,1);Joystick.setButton(4,0);}
  if(buttonState[3]==0){Joystick.setButton(6,1);Joystick.setButton(7,0);}else{Joystick.setButton(7,1);Joystick.setButton(6,0);}
  if(buttonState[4]==0){Joystick.setButton(8,1);Joystick.setButton(9,0);}else{Joystick.setButton(9,1);Joystick.setButton(8,0);}
  if(buttonState[5]==0){Joystick.setButton(10,1);Joystick.setButton(11,0);}else{Joystick.setButton(11,1);Joystick.setButton(10,0);}
  if(buttonState[6]==0){Joystick.setButton(12,1);}else{Joystick.setButton(12,0);}
  if(buttonState[7]==0){Joystick.setButton(13,1);}else{Joystick.setButton(13,0);}
  if(buttonState[8]==0){Joystick.setButton(14,1);}else{Joystick.setButton(14,0);}
  if(buttonState[9]==0){Joystick.setButton(15,1);}else{Joystick.setButton(15,0);}
  if(buttonState[10]==0){Joystick.setButton(16,1);Joystick.setButton(17,0);}else{Joystick.setButton(17,1);Joystick.setButton(16,0);}
  if(buttonState[14]==0){Joystick.setButton(18,1);Joystick.setButton(19,0);}else{Joystick.setButton(19,1);Joystick.setButton(18,0);}
  if(buttonState[15]==0){Joystick.setButton(20,1);Joystick.setButton(21,0);}else{Joystick.setButton(21,1);Joystick.setButton(20,0);}
  if(buttonState[16]==0){Joystick.setButton(22,1);Joystick.setButton(23,0);}else{Joystick.setButton(23,1);Joystick.setButton(22,0);}

  analogA0 = analogRead(A0);
  analogA1 = analogRead(A1);
  //analogA2 = analogRead(A2);
  analogA3 = analogRead(A3);

  int A2_newValue = analogRead(A2);
  A2_sum = A2_sum - A2_samples[A2_writeIndex] + A2_newValue; // 移除旧值，加入新值
  A2_samples[A2_writeIndex] = A2_newValue;                   // 更新缓冲区
  A2_writeIndex = (A2_writeIndex + 1) % A2_Sample_num;    // 循环移动指针
  int A2_analog_average = A2_sum / A2_Sample_num;  //平均值输出
  if (abs(A2_analog_average - A2_last_stable_value) >= stabilityThreshold) {
    A2_last_stable_value = A2_analog_average;  // 超过阈值则更新
  }

  Joystick.setXAxis(A2_last_stable_value);



  if(analogA3<700){Joystick.setButton(24,1);}else{Joystick.setButton(24,0);}
  if(analogA3>=700&&analogA3<800){Joystick.setButton(25,1);}else{Joystick.setButton(25,0);}
  if(analogA3>=800&&analogA3<900){Joystick.setButton(26,1);}else{Joystick.setButton(26,0);}
  if(analogA3>=900&&analogA3<980){Joystick.setButton(27,1);}else{Joystick.setButton(27,0);}
  
  if(analogA1>=50&&analogA1<150){Joystick.setButton(28,1);}else{Joystick.setButton(28,0);}
  if(analogA1>=150&&analogA1<250){Joystick.setButton(29,1);}else{Joystick.setButton(29,0);}
  if(analogA1>=250&&analogA1<350){Joystick.setButton(30,1);}else{Joystick.setButton(30,0);}
  if(analogA1>=350&&analogA1<450){Joystick.setButton(31,1);}else{Joystick.setButton(31,0);}
  if(analogA1>=450&&analogA1<600){Joystick.setButton(32,1);}else{Joystick.setButton(32,0);}
  if(analogA1>=600&&analogA1<700){Joystick.setButton(33,1);}else{Joystick.setButton(33,0);}
  if(analogA1>=700&&analogA1<800){Joystick.setButton(34,1);}else{Joystick.setButton(34,0);}
  if(analogA1>=800&&analogA1<900){Joystick.setButton(35,1);}else{Joystick.setButton(35,0);}
  if(analogA1>=900&&analogA1<1000){Joystick.setButton(36,1);}else{Joystick.setButton(36,0);}
  if(analogA1>=1000){Joystick.setButton(37,1);}else{Joystick.setButton(37,0);}

  if(analogA0<100){Joystick.setButton(45,1);}else{Joystick.setButton(45,0);}
  if(analogA0>=100&&analogA0<250){Joystick.setButton(38,1);}else{Joystick.setButton(38,0);}
  if(analogA0>=250&&analogA0<400){Joystick.setButton(39,1);}else{Joystick.setButton(39,0);}
  if(analogA0>=400&&analogA0<500){Joystick.setButton(40,1);}else{Joystick.setButton(40,0);}
  if(analogA0>=500&&analogA0<650){Joystick.setButton(41,1);}else{Joystick.setButton(41,0);}
  if(analogA0>=650&&analogA0<800){Joystick.setButton(42,1);}else{Joystick.setButton(42,0);}
  if(analogA0>=800&&analogA0<950){Joystick.setButton(43,1);}else{Joystick.setButton(43,0);}
  if(analogA0>=950){Joystick.setButton(44,1);}else{Joystick.setButton(44,0);}


/*

  Serial.print(buttonState[0]);
  Serial.print(buttonState[1]);
  Serial.print(buttonState[2]);
  Serial.print(buttonState[3]);
  Serial.print(buttonState[4]);
  Serial.print(buttonState[5]);
  Serial.print(buttonState[6]);
  Serial.print(buttonState[7]);
  Serial.print(buttonState[8]);
  Serial.print(buttonState[9]);
  Serial.print(buttonState[10]);
  Serial.print(buttonState[14]);
  Serial.print(buttonState[15]);
  Serial.print(buttonState[16]);Serial.print(" ");

  Serial.print(" "); Serial.print(analogA0);
  Serial.print(" "); Serial.print(analogA1);
  Serial.print(" "); Serial.print(A2_last_stable_value);
  Serial.print(" "); Serial.print(analogA3);
  Serial.print(" ");Serial.println(millis()-lasttime);
  */
  
}
